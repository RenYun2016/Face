function [scale1] = count_facesize(imgName)
% imgName='1.jpeg';
img = imread(imgName);
[m,n,T] = size(img);
pts_dir = pwd;
load(fullfile(pwd,[imgName, '.mat']));%pts66
for a=1:1
    for b=1:66
    tempx{a,1}(b,1)=M(1,b+66);
    tempy{a,2}(b,1)=M(1,b);
    pts{a,1}(b,1)=int16(tempx{a,1}(b,1));
    pts{a,2}(b,1)=int16(tempy{a,2}(b,1));   
    end
end
X = img;
Y = rgb2gray(X);
map = face_extraction(pts,Y);
scale1 = sum(sum(map))/(m*n);
