function gmmVJ(imgName)
mean{1,1} = [0.5227    0.3005];
mean{1,2} = [0.3718    0.0287];
mean{1,3} = [0.5392    0.2538];
mean{1,4} = [0.6489    0.0135];
cov1{1,1} = [0.0068   -0.0002;-0.0002    0.0068];
cov1{1,2} = [0.0095    0.0019;0.0019    0.0085];
cov1{1,3} =  [0.0351   -0.0009;-0.0009    0.0391];
cov1{1,4} = [0.0093   -0.0002;-0.0002    0.0121];
mixpro = [0.2603    0.2790    0.1715    0.2893]; 

if ~exist([pwd '\channels\Features'], 'dir')
    mkdir([pwd '\channels\Features']);
end
% imgName='1.jpeg';
img = imread(imgName);
[m,n,T] = size(img);
pts_dir = pwd;
load(fullfile(pwd,[imgName, '.mat']));%pts66
for a=1:1
    for b=1:66
    tempx{a,1}(b,1)=M(1,b+66);
    tempy{a,2}(b,1)=M(1,b);
    pts{a,1}(b,1)=int16(tempx{a,1}(b,1));
    pts{a,2}(b,1)=int16(tempy{a,2}(b,1));   
    end
end
ini_x = double(pts{1,1}(1,1)); 
ini_y = double(pts{1,2}(1,1)); 
ini_l = sqrt(double((double(pts{1,1}(17,1)-ini_x))^2+(double(pts{1,2}(17,1)-ini_y))^2));
for biubiu = 1:4
    cov{1,biubiu} = (ini_l^2)*cov1{1,biubiu};
end
for biu = 1 : 4
    r = double(cov{1,biu}(1,2)/(sqrt(cov{1,biu}(1,1)*cov{1,biu}(2,2))));
    if (biu == 1)  
        x0 = double( (pts{1,2}(49,1)+pts{1,2}(55,1))/2 ); 
        y0 = double( (pts{1,1}(49,1)+pts{1,1}(55,1))/2 ); 
        fangcha(1,biu) = double((double(pts{1,1}(62,1)-pts{1,1}(58,1)))^2+(double(pts{1,2}(62,1)-pts{1,2}(58,1)))^2);
        fangcha(1,biu) = fangcha(1,biu)*2;
    end
    if (biu == 4)  
        x0 = (double(pts{1,2}(43,1))+ double(pts{1,2}(46,1)))/2; 
        y0 = (double(pts{1,1}(43,1))+ double(pts{1,1}(46,1)))/2;
        fangcha(1,biu) = double((double(pts{1,1}(43,1)-pts{1,1}(46,1)))^2+(double(pts{1,2}(43,1)-pts{1,2}(46,1)))^2);
    end
    if (biu == 2)  
        x0 = (double(pts{1,2}(37,1))+ double(pts{1,2}(40,1)))/2; 
        y0 = (double(pts{1,1}(37,1))+ double(pts{1,1}(40,1)))/2;
        fangcha(1,biu) = double((double(pts{1,1}(40,1)-pts{1,1}(37,1)))^2+(double(pts{1,2}(40,1)-pts{1,2}(37,1)))^2);
    end
    if (biu == 3)  
        x0 = double(pts{1,2}(31,1)); 
        y0 = double(pts{1,1}(31,1)); 
        fangcha(1,biu) = double((double(pts{1,1}(29,1)-pts{1,1}(31,1)))^2+(double(pts{1,2}(29,1)-pts{1,2}(31,1)))^2);
    end
    cst = 2*pi*(sqrt(cov{1,biu}(1,1)*cov{1,biu}(2,2))*(sqrt(1-r^2)));
    V{1,biu} = zeros(m,n);%V�Ĵ�СӦ������ͼ��Ĵ�Сƥ��
    for x = 1 : m
        for y = 1 : n              
            t = cov{1,biu}(2,2)*cov{1,biu}(1,1);
            t1 = cov{1,biu}(2,2)/cov{1,biu}(1,1);
            temp1 = ((y-x0)^2)/(fangcha(1,biu)*t1);
            temp2 = ((x-y0)^2)/(fangcha(1,biu));
            temp3 = 2*r*(x-y0)*(y-x0)/(sqrt(t1)*(fangcha(1,biu)));
            V{1,biu}(x,y) = double(double((exp(-temp1-temp2+temp3)))/cst);                  
        end
    end
    norm1 = max(max(V{1,biu}));
    V{1,biu} = V{1,biu} / norm1;
end
for k = 1 : m
    for l = 1 : n
        VJ(k,l) = V{1,1}(k,l)*mixpro(1,1) + V{1,2}(k,l)*mixpro(1,2) + V{1,3}(k,l)*mixpro(1,3) + V{1,4}(k,l)*mixpro(1,4);                 
    end
end
norm1 = max(max(VJ));
GMMVJ = VJ / norm1;
save([pwd '\channels\Features' '\' imgName '.mat'],'GMMVJ'); 
            