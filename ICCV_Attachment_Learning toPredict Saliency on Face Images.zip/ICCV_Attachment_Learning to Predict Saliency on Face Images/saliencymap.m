%---------------------------------------------------------------%
% #ICCV2015# Learning to Predict Saliency on Face Images
% Code by Yun Ren 2015 12 1
%---------------------------------------------------------------%

close all;
currentFolder = pwd;
mex_dir = strcat(pwd,'/mex/');
imgName='1.jpeg';
img = imread(imgName);
[m,n,T] = size(img);

cd(mex_dir);
face_tracker(4,imgName);
cd(currentFolder);


K = load(fullfile(pwd,'/mex/',[imgName '.pts']));
for a=1:1
     for b=1:66
      tempx{a,1}(b,1)=K(a,b+66);
      M(1,b+66) = K(a,b+66);
      tempy{a,2}(b,1)=K(a,b);
      M(1,b) = K(a,b);
      pts{a,1}(b,1)=int16(tempx{a,1}(b,1));
      pts{a,2}(b,1)=int16(tempy{a,2}(b,1)); 
     end
end
save([imgName '.mat'],'M'); 

get_ciomaps(imgName);
our_VJ(imgName)
gmmVJ(imgName);
load(fullfile(pwd, '\count_facesize\train_weight.mat'));%Weight
load(fullfile(pwd,'\count_facesize\train_scale.mat'));%scale/facesize
   scale1 = count_facesize(imgName);
   t=polyfit(scale,Weight(:,5),4);
   wg=polyval(t,scale1);
        if (wg>0.99)
        wg = 0.99;end
        if (wg<0)
        wg = 0.01;end
        if (scale1>0.078)
        wg = 0.82;end
  
    t=polyfit(scale,Weight(:,4),4);
    wf=polyval(t,scale1); 
        if (wf<0)
        wf = 0.01;
        end
        if (scale1>0.13)
        wf = 0.01;end
    
load(fullfile([pwd '\channels\color' '\' imgName '.mat']));%C
load(fullfile([pwd '\channels\intensity' '\' imgName '.mat']));%I
load(fullfile([pwd '\channels\orientation' '\' imgName '.mat']));%O
load(fullfile([pwd '\channels\Face' '\' imgName '.mat']));%Face
load(fullfile([pwd '\channels\Features' '\' imgName '.mat']));%GMMVJ
   norm1 = max(max(colormap)); 
   colormap = colormap / norm1;
   
   norm1 = max(max(intensitymap)); 
   intensitymap = intensitymap / norm1;
   
   norm1 = max(max(orientationmap)); 
   orientationmap = orientationmap / norm1;
   
   norm1 = max(max(VJ)); 
   VJ = VJ / norm1;
   
   norm1 = max(max(GMMVJ)); 
   GMMVJ = GMMVJ / norm1;
   
wc = (0.015689/0.084088)*(1-wg-wf);
wi = (0.005884/0.084088)*(1-wg-wf);
wo = (0.062515/0.084088)*(1-wg-wf);
saliencyMap = wc*colormap + wi*intensitymap +wo*orientationmap + wf*VJ +wg*GMMVJ;
norm1 = max(max(saliencyMap)); 
saliencyMap = saliencyMap / norm1;
save('saliencyMap.mat','saliencyMap');   

%mex -v face_tracker.cpp CLM.obj FCheck.obj FDet.obj IO.obj MxArray.obj Patch.obj PAW.obj PDM.obj Tracker.obj    