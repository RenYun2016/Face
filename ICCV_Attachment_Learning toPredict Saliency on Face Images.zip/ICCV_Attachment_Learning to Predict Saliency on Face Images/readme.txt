#Learning to Predict Saliency on Face Images#

The code has been tested on Windows system, using Matlab 2014, OpenCV 2.4+ and Visual Studio2010.

To compile the code (only for Windows):

1. Put the extracted files in a **<pwd_dir>**.

2. Install OpenCV 2.4+.(2.4.10 for example).

3. Go to **<pwd_dir>**. Put the folders of **<pwd_dir>** into the matlab path.

4. matlab >>mex -v face_tracker.cpp CLM.obj FCheck.obj FDet.obj IO.obj MxArray.obj Patch.obj PAW.obj PDM.obj Tracker.obj -I'D:\Program Files (x86)\opencv\build\include\' -I'D:\Program Files (x86)\opencv\build\include\opencv\' -I'D:\Program Files (x86)\opencv\build\include\opencv2\' -L'D:\Program Files (x86)\opencv\build\x64\vc10\lib\'-lopencv_core2410d -lopencv_highgui2410d -lopencv_imgproc2410d
%Note:The paths of OPENCV is correspongding to yours.%

5. Run **saliencymap.m** in Matlab.

6. Get the **saliencymap.mat** for saliency map in the **<pwd_dir>**.

'1.jpeg' for test. 
It should be easy to compile the mex file on other platforms, too.

