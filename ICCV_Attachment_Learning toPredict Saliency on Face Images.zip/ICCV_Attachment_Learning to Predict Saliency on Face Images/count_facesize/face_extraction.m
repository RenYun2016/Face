function [map] = face_extraction(xy,Y)
    k=1;
    xmax=max(xy{1,1});
    map = zeros(size(Y,1),size(Y,2));

%���������ı߽�㣬����Ŀ������߽������
%����
%����
x1{1}=xy{1,1}(1,1):1:xy{1,1}(2,1);
a1=xy{1,2}(1,1)-xy{1,2}(2,1);
b1=xy{1,1}(1,1)-xy{1,1}(2,1);
a1=double(a1);
b1=double(b1);
y1{1}=a1/b1*(x1{1}-xy{1,1}(1,1))+xy{1,2}(1,1);
for i=2:8
    x1{i}=xy{k,1}(i,1)+1:xy{k,1}(i+1,1);
    a = xy{k,2}(i,1)-xy{k,2}(i+1,1);
    b = xy{k,1}(i,1)-xy{k,1}(i+1,1);
    a = double(a);
    b = double(b);
    y1{i}=a/b*(x1{i}-xy{k,1}(i,1))+xy{k,2}(i,1);
end
xx11=cell2mat(x1);
yy11=cell2mat(y1);
for i = 1:length(xx11')
    map(xx11(i),yy11(i)) = 1;
end
%����
x1{1}=xy{k,1}(17,1):1:xy{k,1}(16,1);
a = xy{k,2}(17,1)-xy{k,2}(16,1);
b = xy{k,1}(17,1)-xy{k,1}(16,1);
a=double(a);
b=double(b);
y1{1}=a/b*(x1{1}-xy{k,1}(17,1))+xy{k,2}(17,1);
for i=15:-1:9
    x1{17-i}=xy{k,1}(i+1,1)+1:1:xy{k,1}(i,1);
    a=xy{k,2}(i+1,1)-xy{k,2}(i,1);
    b=xy{k,1}(i+1,1)-xy{k,1}(i,1);
    a=double(a);
    b=double(b);
    y1{17-i}=a/b*(x1{17-i}-xy{k,1}(i+1,1))+xy{k,2}(i+1,1);
end
xx12=cell2mat(x1);
yy12=cell2mat(y1);
for i = 1:length(xx12')
    map(xx12(i),yy12(i)) = 1;
end
%üë
y2{1}=xy{k,2}(18,1):1:xy{k,2}(18+1,1);
a=xy{k,1}(18,1)-xy{k,1}(18+1,1);
b=xy{k,2}(18,1)-xy{k,2}(18+1,1);
a=double(a);
b=double(b);
x2{1}=a/b*(y2{1}-xy{k,2}(18,1))+xy{k,1}(18,1);
for i=19:26
    y2{i-18+1}=xy{k,2}(i,1)+1:1:xy{k,2}(i+1,1);
    a=xy{k,1}(i,1)-xy{k,1}(i+1,1);
    b=xy{k,2}(i,1)-xy{k,2}(i+1,1);
    a=double(a);
    b=double(b);
    x2{i-18+1}=a/b*(y2{i-18+1}-xy{k,2}(i,1))+xy{k,1}(i,1);
end
xx2=cell2mat(x2);
yy2=cell2mat(y2);
for i = 1:length(xx2')
    map(xx2(i),yy2(i)) = 1;
end
%���üë������
y3{1}=xy{k,2}(1,1):1:xy{k,2}(18,1);
x3{1}=((xy{k,1}(18,1)-xy{k,1}(1,1))/(xy{k,2}(18,1)-xy{k,2}(1,1)))*(y3{1}-xy{k,2}(18,1))+xy{k,1}(18,1); 
for i = 1:length(x3{1}')
    map(x3{1}(i),y3{1}(i)) = 1;
end
%����üë������
 y4{1}=xy{k,2}(27,1):1:xy{k,2}(17,1);
 x4{1}=((xy{k,1}(27,1)-xy{k,1}(17,1))/(xy{k,2}(27,1)-xy{k,2}(17,1)))*(y4{1}-xy{k,2}(27,1))+xy{k,1}(27,1);
for i = 1:length(x4{1}')
    map(x4{1}(i),y4{1}(i)) = 1;
end

x=zeros(1,7);
y=zeros(1,7);
%����
c=1;
xlabel=find(xy{k,1}==xmax);
s=size(xlabel)/2;
S=int16(s);
y_xmax=xy{k,2}(xlabel(S(1)),1);
for i=xy{k,1}(1,1):xmax
   for j=xy{k,2}(1,1):y_xmax
    if j>yy11(1,min(i-xy{k,1}(1,1)+1,length(yy11)))% if j>yy11(1,i-xy{k,1}(1,1)+1)
     map(i,j) = 1;
     c=c+1;
    end
   end
end 
%����
a=1;
for i=xy{k,1}(17,1):xmax
   for j=y_xmax+1:xy{k,2}(17,1)
    if j<yy12(1,min(i-xy{k,1}(17,1)+1,length(yy12))) % if j<yy12(1,i-xy{k,1}(17,1)+1)
     map(i,j) = 1;
     a=a+1;
    end
end
end

%üë
b=1;
for j=xy{k,2}(18,1):xy{k,2}(27,1)
   for i=min(xy{k,1}(18:27,1)):max(xy{k,1}(18:27,1))
    if i>xx2(1,j-xy{k,2}(18,1)+1)
       map(i,j) = 1;
      b=b+1;
    end
end
end
%������
e=1;
for j=xy{k,2}(1,1):xy{k,2}(18,1)
   for i=xy{k,1}(1,1):-1:xy{k,1}(18,1)
    if i>x3{1}(1,j+1-xy{k,2}(1,1))
       map(i,j) = 1;
      e=e+1;
    end
   end
end


%������
f=1;
for j=xy{k,2}(27,1):xy{k,2}(17,1)
   for i=xy{k,1}(27,1):xy{k,1}(17,1)
    if i>x4{1}(1,j+1-xy{k,2}(27,1))
       map(i,j) = 1;
      f=f+1;
    end
   end
end  

%ʣ�ಿ��
g=1;
for i=max(xy{k,1}(18:27,1)):xy{k,1}(1,1)
    for j=xy{k,2}(18,1):y_xmax
             map(i,j) = 1;
      g=g+1;
    end
end
h=1;
for i=max(xy{k,1}(18:27,1)):xy{k,1}(17,1)
    for j=y_xmax:xy{k,2}(27,1)
             map(i,j) = 1;
      h=h+1;
    end
end