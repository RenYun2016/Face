function get_ciomaps(imgName)
SAVE_DIR = pwd;
channel_dir = strcat(pwd,'/channels/');
if ~exist(channel_dir, 'dir')
    mkdir(channel_dir);
end
FEATURES{1} ='\channels\color';
FEATURES{2} ='\channels\intensity';
FEATURES{3} ='\channels\orientation';
for feature = 1: 3
            if ~exist([SAVE_DIR FEATURES{feature}], 'dir')
                mkdir([SAVE_DIR FEATURES{feature}]);
            end
end
% imgName='1.jpeg';
img = imread(imgName);
[m,n,T] = size(img);

params = makeGBVSParams;
out = gbvs(img,params);           
colormap = out.cmaps{1};
intensitymap = out.cmaps{2};
orientationmap = out.cmaps{3};
           
save([SAVE_DIR FEATURES{1} '\' imgName '.mat'], 'colormap');
save([SAVE_DIR FEATURES{2} '\' imgName '.mat'], 'intensitymap');
save([SAVE_DIR FEATURES{3} '\' imgName '.mat'], 'orientationmap');
