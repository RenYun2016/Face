function our_VJ(imgName)
if ~exist([pwd '\channels\Face'], 'dir')
    mkdir([pwd '\channels\Face']);
end
% imgName='1.jpeg';
img = imread(imgName);
[m,n,T] = size(img);
pts_dir = pwd;
load(fullfile(pwd,[imgName, '.mat']));%pts66
for a=1:1
    for b=1:66
    tempx{a,1}(b,1)=M(1,b+66);
    tempy{a,2}(b,1)=M(1,b);
    pts{a,1}(b,1)=int16(tempx{a,1}(b,1));
    pts{a,2}(b,1)=int16(tempy{a,2}(b,1));
    %plot(pts{a,2}(b,1),pts{a,1}(b,1),'r.','MarkerSize',14);  
    end
end
ini_x = double(pts{1,1}(1,1)); 
ini_y = double(pts{1,2}(1,1)); 
ini_l = sqrt(double((double(pts{1,1}(17,1)-ini_x))^2+(double(pts{1,2}(17,1)-ini_y))^2)); 
x0 = double(pts{1,2}(18,1)+pts{1,2}(27,1))/2; 
y0 = double(pts{1,1}(28,1)+pts{1,1}(9,1))/2;
l1 = sqrt(double((double(pts{1,1}(17,1)-pts{1,1}(1,1)))^2+(double(pts{1,2}(17,1)-pts{1,2}(1,1)))^2)); 
l1 = l1/2*1.1;
l2 = l1*sqrt(0.0391/0.0243);
r0 = (l1+l2)/2;
VJ = zeros(m,n);%VJ�Ĵ�СӦ������ͼ��Ĵ�Сƥ��
for x = 1 : m
   for y = 1 : n              
       VJ(x,y) = VJ(x,y) + exp(-((x-y0)^2)/l2^2-((y-x0)^2)/l1^2);
   end
end
norm1 = max(max(VJ)); 
VJ = VJ / norm1;
save([pwd '\channels\Face' '\' imgName '.mat'],'VJ');
